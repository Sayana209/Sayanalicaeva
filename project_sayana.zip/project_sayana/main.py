# main.py
# ШАГ 9: Главный файл приложения
# Здесь регистрируем все роуты и запускаем сервер

from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session, joinedload

import models
import auth
from database import engine, Base, get_db
from routers import auth_router, stories_router, users_router


# ШАГ 9.1: Lifespan — код выполняется при старте и завершении приложения
# Здесь создаём таблицы в БД если их ещё нет
@asynccontextmanager
async def lifespan(app: FastAPI):
    # При старте: создать все таблицы
    Base.metadata.create_all(bind=engine)
    print("✅ База данных готова")
    yield
    # При завершении: здесь можно закрыть соединения, очистить кэш и т.д.
    print("👋 Сервер остановлен")


# ШАГ 9.2: Создаём экземпляр FastAPI
app = FastAPI(
    title="Сборник рассказов",
    description="Платформа для писателей и читателей",
    version="1.0.0",
    lifespan=lifespan,
)

# ШАГ 9.3: Подключаем статические файлы (CSS, JS, изображения)
app.mount("/static", StaticFiles(directory="static"), name="static")

# ШАГ 9.4: Настраиваем Jinja2 — движок HTML-шаблонов
templates = Jinja2Templates(directory="templates")

# ШАГ 9.5: Регистрируем роутеры
# Роутер — это группа связанных маршрутов, вынесенная в отдельный файл
app.include_router(auth_router.router)
app.include_router(stories_router.router)
app.include_router(users_router.router)


# ШАГ 9.6: Главная страница
@app.get("/", response_class=HTMLResponse)
async def index(
    request: Request,
    genre: str | None = None,  # Фильтр по жанру (query параметр: /?genre=Фантастика)
    db: Session = Depends(get_db),
):
    """
    Главная страница со списком рассказов.
    Depends(get_db) — FastAPI автоматически передаст сессию БД и закроет её после запроса.
    """
    query = (
        db.query(models.Story)
        .options(joinedload(models.Story.author))  # Загрузить автора одним JOIN
        .filter(models.Story.is_published == True)
        .order_by(models.Story.created_at.desc())  # Новые рассказы первыми
    )

    if genre:
        query = query.filter(models.Story.genre == genre)

    stories = query.limit(20).all()

    # Получаем список жанров для фильтра
    genres = ["Фантастика", "Фэнтези", "Детектив", "Романтика", "Хоррор", "Приключения", "Драма", "Юмор", "Другое"]

    current_user = auth.get_current_user(request, db)

    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "stories": stories,
            "genres": genres,
            "selected_genre": genre,
            "current_user": current_user,
        },
    )


@app.get("/profile/{username}", response_class=HTMLResponse)
async def profile(username: str, request: Request, db: Session = Depends(get_db)):
    """Страница профиля пользователя."""
    user = db.query(models.User).filter(models.User.username == username).first()
    if not user:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    stories = (
        db.query(models.Story)
        .filter(models.Story.author_id == user.id, models.Story.is_published == True)
        .order_by(models.Story.created_at.desc())
        .all()
    )

    current_user = auth.get_current_user(request, db)

    return templates.TemplateResponse(
        "profile.html",
        {"request": request, "profile_user": user, "stories": stories, "current_user": current_user},
    )


# ШАГ 10: Запуск сервера (только при прямом запуске файла)
if __name__ == "__main__":
    import uvicorn
    # uvicorn — ASGI-сервер, запускает асинхронное FastAPI-приложение
    # reload=True — автоматически перезапускать при изменении файлов (только для разработки!)
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
