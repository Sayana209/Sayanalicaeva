# auth.py
# ШАГ 6: Логика авторизации
# JWT (JSON Web Token) — это зашифрованный токен, который хранится в cookie
# Схема: пользователь входит → сервер выдаёт токен → токен хранится в браузере
# При каждом запросе сервер проверяет токен и узнаёт, кто делает запрос

from datetime import datetime, timedelta, timezone
from typing import Optional
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi import Request, HTTPException, status
from sqlalchemy.orm import Session
import models

SECRET_KEY = "Sayana_KEY"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # Токен живёт 7 дней

# Контекст для хэширования паролей через bcrypt
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    """Хэшировать пароль перед сохранением в БД. Никогда не храним пароли в открытом виде!"""
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Проверить, совпадает ли введённый пароль с хэшем из БД."""
    return pwd_context.verify(plain_password, hashed_password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """
    Создать JWT-токен.
    data — словарь с данными (обычно {"sub": username, "role": role})
    Токен содержит зашифрованные данные + время истечения
    """
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> Optional[dict]:
    """Расшифровать JWT-токен. Возвращает данные или None если токен невалиден."""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        return None


def get_current_user(request: Request, db: Session) -> Optional[models.User]:
    """
    Получить текущего пользователя из cookie.
    Эта функция вызывается в каждом защищённом роуте.
    """
    token = request.cookies.get("access_token")
    if not token:
        return None

    payload = decode_token(token)
    if not payload:
        return None

    username: str = payload.get("sub")
    if not username:
        return None

    user = db.query(models.User).filter(models.User.username == username).first()
    return user


def require_writer(request: Request, db: Session) -> models.User:
    """Проверить, что пользователь авторизован и имеет роль 'writer'."""
    user = get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Необходима авторизация")
    if user.role != "writer":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Только для писателей")
    return user
