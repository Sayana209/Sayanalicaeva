# schemas.py
# ШАГ 5: Pydantic-схемы для валидации данных
# Pydantic v2 проверяет входящие данные и формирует ответы API
# Это "договор" между фронтендом и бэкендом

from datetime import datetime
from pydantic import BaseModel, EmailStr, field_validator, ConfigDict


# ─── Пользователи ─────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    """Данные для регистрации нового пользователя."""
    username: str
    email: EmailStr
    password: str
    role: str = "reader"  # По умолчанию — читатель

    @field_validator("username")
    @classmethod
    def username_valid(cls, v: str) -> str:
        if len(v) < 3:
            raise ValueError("Имя пользователя должно быть не менее 3 символов")
        if not v.isalnum():
            raise ValueError("Имя пользователя должно содержать только буквы и цифры")
        return v

    @field_validator("password")
    @classmethod
    def password_strong(cls, v: str) -> str:
        if len(v) < 6:
            raise ValueError("Пароль должен быть не менее 6 символов")
        return v


class UserOut(BaseModel):
    """Данные пользователя, которые возвращаем в ответе (без пароля!)."""
    model_config = ConfigDict(from_attributes=True)  # Позволяет создать из SQLAlchemy-объекта

    id: int
    username: str
    email: str
    role: str
    bio: str | None
    created_at: datetime


# ─── Авторизация ──────────────────────────────────────────────────────────────

class LoginForm(BaseModel):
    """Форма входа."""
    username: str
    password: str


# ─── Рассказы ─────────────────────────────────────────────────────────────────

class StoryCreate(BaseModel):
    """Данные для создания рассказа."""
    title: str
    content: str
    summary: str | None = None
    genre: str | None = None
    is_published: bool = True

    @field_validator("title")
    @classmethod
    def title_not_empty(cls, v: str) -> str:
        if len(v.strip()) < 3:
            raise ValueError("Заголовок слишком короткий")
        return v.strip()

    @field_validator("content")
    @classmethod
    def content_not_empty(cls, v: str) -> str:
        if len(v.strip()) < 50:
            raise ValueError("Текст рассказа должен быть не менее 50 символов")
        return v.strip()


class StoryOut(BaseModel):
    """Данные рассказа для ответа API."""
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    content: str
    summary: str | None
    genre: str | None
    is_published: bool
    views: int
    created_at: datetime
    author: UserOut


# ─── Комментарии ──────────────────────────────────────────────────────────────

class CommentCreate(BaseModel):
    """Данные для создания комментария."""
    content: str

    @field_validator("content")
    @classmethod
    def content_not_empty(cls, v: str) -> str:
        if len(v.strip()) < 2:
            raise ValueError("Комментарий слишком короткий")
        return v.strip()


class CommentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    content: str
    created_at: datetime
    author: UserOut
