# routers/stories_router.py
# ШАГ 8: Роуты для рассказов
# GET /stories/{id} — прочитать рассказ
# GET /write — редактор (только для писателей)
# POST /stories — создать рассказ
# POST /stories/{id}/comment — добавить комментарий
# POST /stories/{id}/delete — удалить рассказ

from fastapi import APIRouter, Depends, HTTPException, Request, Form, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload

import models
import auth
from database import get_db

router = APIRouter(tags=["stories"])
templates = Jinja2Templates(directory="templates")

GENRES = ["Фантастика", "Фэнтези", "Детектив", "Романтика", "Хоррор", "Приключения", "Драма", "Юмор", "Другое"]


@router.get("/write", response_class=HTMLResponse)
async def write_page(request: Request, db: Session = Depends(get_db)):
    """Страница редактора — только для писателей."""
    current_user = auth.get_current_user(request, db)
    if not current_user:
        return RedirectResponse(url="/auth/login", status_code=status.HTTP_302_FOUND)
    if current_user.role != "writer":
        raise HTTPException(status_code=403, detail="Только для писателей")

    return templates.TemplateResponse(
        "write.html", {"request": request, "current_user": current_user, "genres": GENRES}
    )


@router.post("/stories")
async def create_story(
    request: Request,
    title: str = Form(...),
    content: str = Form(...),
    summary: str = Form(default=""),
    genre: str = Form(default="Другое"),
    is_published: bool = Form(default=True),
    db: Session = Depends(get_db),
):
    """Создать новый рассказ. Только для авторизованных писателей."""
    current_user = auth.get_current_user(request, db)
    if not current_user or current_user.role != "writer":
        raise HTTPException(status_code=403, detail="Только для писателей")

    story = models.Story(
        title=title.strip(),
        content=content.strip(),
        summary=summary.strip() if summary else None,
        genre=genre,
        is_published=is_published,
        author_id=current_user.id,
    )
    db.add(story)
    db.commit()
    db.refresh(story)

    return RedirectResponse(url=f"/stories/{story.id}", status_code=status.HTTP_302_FOUND)


@router.get("/stories/{story_id}", response_class=HTMLResponse)
async def story_detail(story_id: int, request: Request, db: Session = Depends(get_db)):
    """
    Страница рассказа.
    joinedload — загружаем автора и комментарии одним запросом (оптимизация N+1)
    """
    story = (
        db.query(models.Story)
        .options(
            joinedload(models.Story.author),
            joinedload(models.Story.comments).joinedload(models.Comment.author),
        )
        .filter(models.Story.id == story_id)
        .first()
    )

    if not story:
        raise HTTPException(status_code=404, detail="Рассказ не найден")

    # Увеличиваем счётчик просмотров
    story.views += 1
    db.commit()

    current_user = auth.get_current_user(request, db)

    # Сортируем комментарии по дате (новые снизу)
    comments = sorted(story.comments, key=lambda c: c.created_at)

    return templates.TemplateResponse(
        "story.html",
        {
            "request": request,
            "story": story,
            "comments": comments,
            "current_user": current_user,
        },
    )


@router.post("/stories/{story_id}/comment")
async def add_comment(
    story_id: int,
    request: Request,
    content: str = Form(...),
    db: Session = Depends(get_db),
):
    """Добавить комментарий к рассказу. Для авторизованных пользователей."""
    current_user = auth.get_current_user(request, db)
    if not current_user:
        return RedirectResponse(url="/auth/login", status_code=status.HTTP_302_FOUND)

    story = db.query(models.Story).filter(models.Story.id == story_id).first()
    if not story:
        raise HTTPException(status_code=404, detail="Рассказ не найден")

    comment = models.Comment(
        content=content.strip(),
        story_id=story_id,
        author_id=current_user.id,
    )
    db.add(comment)
    db.commit()

    return RedirectResponse(url=f"/stories/{story_id}#comments", status_code=status.HTTP_302_FOUND)


@router.post("/stories/{story_id}/delete")
async def delete_story(story_id: int, request: Request, db: Session = Depends(get_db)):
    """Удалить рассказ — только автор или (в будущем) администратор."""
    current_user = auth.get_current_user(request, db)
    if not current_user:
        raise HTTPException(status_code=401, detail="Необходима авторизация")

    story = db.query(models.Story).filter(models.Story.id == story_id).first()
    if not story:
        raise HTTPException(status_code=404, detail="Рассказ не найден")

    if story.author_id != current_user.id:
        raise HTTPException(status_code=403, detail="Нет прав на удаление")

    db.delete(story)
    db.commit()

    return RedirectResponse(url="/", status_code=status.HTTP_302_FOUND)
