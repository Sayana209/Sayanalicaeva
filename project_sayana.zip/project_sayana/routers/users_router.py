# routers/users_router.py
# Роуты для управления профилем пользователя:
# GET  /users/me          — посмотреть свой профиль
# POST /users/me/edit     — редактировать bio
# POST /users/me/password — сменить пароль

from fastapi import APIRouter, Depends, Request, Form, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

import auth
import models
from database import get_db

router = APIRouter(prefix="/users", tags=["users"])
templates = Jinja2Templates(directory="templates")


@router.get("/me", response_class=HTMLResponse)
async def my_profile(request: Request, db: Session = Depends(get_db)):
    """Редирект на страницу своего профиля."""
    current_user = auth.get_current_user(request, db)
    if not current_user:
        return RedirectResponse(url="/auth/login", status_code=status.HTTP_302_FOUND)
    return RedirectResponse(url=f"/profile/{current_user.username}", status_code=status.HTTP_302_FOUND)


@router.get("/me/edit", response_class=HTMLResponse)
async def edit_profile_page(request: Request, db: Session = Depends(get_db)):
    """Страница редактирования профиля."""
    current_user = auth.get_current_user(request, db)
    if not current_user:
        return RedirectResponse(url="/auth/login", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse(
        "edit_profile.html", {"request": request, "current_user": current_user}
    )


@router.post("/me/edit")
async def edit_profile(
    request: Request,
    bio: str = Form(default=""),
    db: Session = Depends(get_db),
):
    """Сохранить изменения профиля."""
    current_user = auth.get_current_user(request, db)
    if not current_user:
        return RedirectResponse(url="/auth/login", status_code=status.HTTP_302_FOUND)

    current_user.bio = bio.strip() if bio.strip() else None
    db.commit()

    return RedirectResponse(url=f"/profile/{current_user.username}", status_code=status.HTTP_302_FOUND)


@router.post("/me/password")
async def change_password(
    request: Request,
    current_password: str = Form(...),
    new_password: str = Form(...),
    db: Session = Depends(get_db),
):
    """Сменить пароль."""
    current_user = auth.get_current_user(request, db)
    if not current_user:
        return RedirectResponse(url="/auth/login", status_code=status.HTTP_302_FOUND)

    if not auth.verify_password(current_password, current_user.hashed_password):
        return templates.TemplateResponse(
            "edit_profile.html",
            {
                "request": request,
                "current_user": current_user,
                "password_error": "Неверный текущий пароль",
            },
        )

    if len(new_password) < 6:
        return templates.TemplateResponse(
            "edit_profile.html",
            {
                "request": request,
                "current_user": current_user,
                "password_error": "Новый пароль должен быть не менее 6 символов",
            },
        )

    current_user.hashed_password = auth.hash_password(new_password)
    db.commit()

    return templates.TemplateResponse(
        "edit_profile.html",
        {
            "request": request,
            "current_user": current_user,
            "password_success": "Пароль успешно изменён",
        },
    )
