# routers/auth_router.py
# ШАГ 7: Роуты регистрации и входа
# POST /auth/register — создать аккаунт
# POST /auth/login — войти и получить cookie с токеном
# POST /auth/logout — выйти (удалить cookie)

from fastapi import APIRouter, Depends, HTTPException, status, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

import models
import auth
from database import get_db

router = APIRouter(prefix="/auth", tags=["auth"])
templates = Jinja2Templates(directory="templates")


@router.get("/register", response_class=HTMLResponse)
async def register_page(request: Request, db: Session = Depends(get_db)):
    """Страница регистрации."""
    current_user = auth.get_current_user(request, db)
    return templates.TemplateResponse(
        "register.html", {"request": request, "current_user": current_user}
    )


@router.post("/register")
async def register(
    request: Request,
    username: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    role: str = Form(default="reader"),
    db: Session = Depends(get_db),
):
    """
    Обработка формы регистрации.
    Form(...) — получаем данные из HTML-формы (application/x-www-form-urlencoded)
    """
    # Проверяем, не занято ли имя пользователя
    existing_user = db.query(models.User).filter(
        (models.User.username == username) | (models.User.email == email)
    ).first()

    if existing_user:
        return templates.TemplateResponse(
            "register.html",
            {
                "request": request,
                "error": "Пользователь с таким именем или email уже существует",
                "current_user": None,
            },
        )

    # Создаём нового пользователя с хэшированным паролем
    new_user = models.User(
        username=username,
        email=email,
        hashed_password=auth.hash_password(password),
        role=role if role in ("reader", "writer") else "reader",
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # После регистрации сразу логиним пользователя
    token = auth.create_access_token({"sub": new_user.username, "role": new_user.role})
    response = RedirectResponse(url="/", status_code=status.HTTP_302_FOUND)
    # httponly=True — JavaScript не может читать этот cookie (защита от XSS)
    response.set_cookie(key="access_token", value=token, httponly=True, max_age=60 * 60 * 24 * 7)
    return response


@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, db: Session = Depends(get_db)):
    """Страница входа."""
    current_user = auth.get_current_user(request, db)
    return templates.TemplateResponse(
        "login.html", {"request": request, "current_user": current_user}
    )


@router.post("/login")
async def login(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    """Обработка формы входа."""
    user = db.query(models.User).filter(models.User.username == username).first()

    # Проверяем пользователя и пароль
    if not user or not auth.verify_password(password, user.hashed_password):
        return templates.TemplateResponse(
            "login.html",
            {
                "request": request,
                "error": "Неверное имя пользователя или пароль",
                "current_user": None,
            },
        )

    # Создаём токен и сохраняем в cookie
    token = auth.create_access_token({"sub": user.username, "role": user.role})
    response = RedirectResponse(url="/", status_code=status.HTTP_302_FOUND)
    response.set_cookie(key="access_token", value=token, httponly=True, max_age=60 * 60 * 24 * 7)
    return response


@router.post("/logout")
async def logout():
    """Выход — удаляем cookie с токеном."""
    response = RedirectResponse(url="/", status_code=status.HTTP_302_FOUND)
    response.delete_cookie(key="access_token")
    return response
