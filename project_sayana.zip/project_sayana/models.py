# models.py
# ШАГ 4: Модели базы данных
# Каждый класс = одна таблица в БД
# SQLAlchemy автоматически создаёт таблицы при запуске

from datetime import datetime, timezone
from sqlalchemy import String, Text, Boolean, DateTime, ForeignKey, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from database import Base


class User(Base):
    """
    Таблица пользователей.
    Роли: 'writer' (может писать рассказы) и 'reader' (только читает).
    """
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    username: Mapped[str] = mapped_column(String(50), unique=True, index=True, nullable=False)
    email: Mapped[str] = mapped_column(String(100), unique=True, index=True, nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(20), default="reader")  # 'reader' или 'writer'
    bio: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )

    # Связь один-ко-многим: один пользователь → много рассказов
    stories: Mapped[list["Story"]] = relationship("Story", back_populates="author", cascade="all, delete")
    comments: Mapped[list["Comment"]] = relationship("Comment", back_populates="author", cascade="all, delete")


class Story(Base):
    """
    Таблица рассказов.
    Рассказ может быть черновиком (is_published=False) или опубликованным.
    """
    __tablename__ = "stories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    summary: Mapped[str | None] = mapped_column(String(500), nullable=True)  # Краткое описание
    genre: Mapped[str | None] = mapped_column(String(50), nullable=True)
    is_published: Mapped[bool] = mapped_column(Boolean, default=True)
    views: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    # Внешний ключ — ссылка на автора
    author_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)

    # Обратная связь: рассказ знает своего автора
    author: Mapped["User"] = relationship("User", back_populates="stories")
    comments: Mapped[list["Comment"]] = relationship("Comment", back_populates="story", cascade="all, delete")


class Comment(Base):
    """Таблица комментариев к рассказам."""
    __tablename__ = "comments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )

    story_id: Mapped[int] = mapped_column(ForeignKey("stories.id"), nullable=False)
    author_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)

    story: Mapped["Story"] = relationship("Story", back_populates="comments")
    author: Mapped["User"] = relationship("User", back_populates="comments")
