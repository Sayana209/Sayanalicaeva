# database.py
# ШАГ 3: Настройка подключения к базе данных
# SQLAlchemy 2.0 использует новый стиль с DeclarativeBase
# SQLite хранит всё в одном файле — идеально для старта

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

# URL базы данных — файл stories.db создастся автоматически в папке проекта
DATABASE_URL = "sqlite:///./stories.db"

# Создаём движок БД
# check_same_thread=False нужно только для SQLite при работе с FastAPI
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=False,  # True — выводить SQL-запросы в консоль (удобно при отладке)
)

# Фабрика сессий — каждый запрос получает свою сессию
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


# Базовый класс для всех моделей (новый стиль SQLAlchemy 2.0)
class Base(DeclarativeBase):
    pass


# Dependency для FastAPI — выдаёт сессию и закрывает её после запроса
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
